<div class="modal fade" id="createNewsModal">
    <div class="modal-dialog">
        <div class="modal-content">

            <form action="<?= base_url('home_Page_managment_controller/create_projects'); ?>" method="post" enctype="multipart/form-data">

                <div class="modal-header">
                    <h5 class="modal-title">Create Project</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">

                    <div class="form-group">
                        <label>title</label>
                        <input type="text" name="title" class="form-control" placeholder="Enter title" required>
                    </div>

                    <div class="form-group">
                        <label>Details</label>
                        <textarea name="details" class="form-control" placeholder="Enter details" required></textarea>
                    </div>
                    <div class="form-group">
                        <label >Image</label>
                        <div style="position:relative;">
                            <input type="file" name="image" id="image" class="form-control"></input>
                        </div>
                    </div>


                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success btn-sm">Save</button>
                </div>

            </form>

        </div>
    </div>
</div>




<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>